#ifndef HASH_H
#define HASH_H


#define MAX_DOCUMENTOS 100
#define MAX_TAMANHO_PALAVRA 20  
#define MAX_TAMANHO_DOCUMENTO 50   
#define MAX_TAMANHO_VOCABULARIO 1000
#define MAX_PALAVRAS_BUSCADAS 100
#define MAX_PALAVRAS_POR_DOCUMENTO 1000
#define MAX_TAMANHO_LINHA 1000
#define VAZIO "VAZIO"
#define REMOVIDO "REMOVIDO"

typedef struct Documento {
    char nome[MAX_TAMANHO_DOCUMENTO + 1];
} Documento;

typedef struct EntradaHash {
    char palavra[MAX_TAMANHO_PALAVRA + 1];
    Documento documentos[MAX_DOCUMENTOS];
    int qtdDocumentos;
    struct EntradaHash *proximo; // Ponteiro para o próximo elemento na lista encadeada
} EntradaHash;

typedef struct HashTable {
    EntradaHash **tabela; // Vetor de ponteiros para listas encadeadas
    int tamanho;
    int (*hash2)(char*, int); // Ponteiro para a segunda função hash
} HashTable;

// Funções básicas
HashTable* criaHash(int tamanho);
int insereHash(HashTable *hash, char *palavra, char *documento);
int buscaHash(HashTable *hash, char *palavra, EntradaHash **resultado);

// Funções de hash
int hashFunction1(char *chave, int m);
int hashFunction2(char *chave, int m);

#endif // HASH_H