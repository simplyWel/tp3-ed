#include "hash.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Primeira função hash (original)
int hashFunction1(char *chave, int m) {
    float p[] = {0.8326030060567271, 0.3224428884580177, 
                 0.6964223353369197, 0.1966079596929834, 
                 0.8949283476433433, 0.4587297824155836, 
                 0.5100785238948532, 0.05356055934904358, 
                 0.9157270141062215, 0.7278472432221632};
    int tamP = 10;
    unsigned int soma = 0;
    for (int i = 0; chave[i] != '\0'; i++) {
        soma += (unsigned int)chave[i] * p[i % tamP];
    }
    return soma % m;
}

// Segunda função hash para hashing duplo
int hashFunction2(char *chave, int m) {
    unsigned int hash = 0;
    for (int i = 0; chave[i] != '\0'; i++) {
        hash = (hash * 31 + chave[i]) % m;
    }
    return (hash % (m - 1)) + 1; // Garante que o passo nunca seja zero
}

// Cria a tabela hash
HashTable* criaHash(int tamanho) {
    if (tamanho <= 0) return NULL;

    HashTable *hash = (HashTable*)malloc(sizeof(HashTable));
    if (!hash) return NULL;

    hash->tabela = (EntradaHash**)calloc(tamanho, sizeof(EntradaHash*));
    if (!hash->tabela) {
        free(hash);
        return NULL;
    }

    hash->tamanho = tamanho;
    hash->hash2 = hashFunction2; // Define a segunda função hash
    return hash;
}


// Insere uma palavra e documento na tabela hash
int insereHash(HashTable *hash, char *palavra, char *documento) {
    if (!hash || !palavra || !documento) return 0;

    int idx = hashFunction1(palavra, hash->tamanho);
    int step = hash->hash2(palavra, hash->tamanho);

    for (int i = 0; i < hash->tamanho; i++) {
        int pos = (idx + i * step) % hash->tamanho;

        EntradaHash *atual = hash->tabela[pos];
        EntradaHash *anterior = NULL;

        // Verifica se a palavra já existe na lista encadeada
        while (atual) {
            if (strcmp(atual->palavra, palavra) == 0) {
                // Verifica se o documento já está associado
                for (int j = 0; j < atual->qtdDocumentos; j++) {
                    if (strcmp(atual->documentos[j].nome, documento) == 0) {
                        return 1; // Documento já existe
                    }
                }

                // Adiciona o documento à entrada existente
                if (atual->qtdDocumentos < MAX_DOCUMENTOS) {
                    strncpy(atual->documentos[atual->qtdDocumentos].nome, documento, MAX_TAMANHO_DOCUMENTO);
                    atual->qtdDocumentos++;
                    return 1;
                }
                return 0; // Limite de documentos atingido
            }
            anterior = atual;
            atual = atual->proximo;
        }

        // Palavra não encontrada, cria uma nova entrada
        EntradaHash *novaEntrada = (EntradaHash*)malloc(sizeof(EntradaHash));
        if (!novaEntrada) return 0;

        strncpy(novaEntrada->palavra, palavra, MAX_TAMANHO_PALAVRA);
        strncpy(novaEntrada->documentos[0].nome, documento, MAX_TAMANHO_DOCUMENTO);
        novaEntrada->qtdDocumentos = 1;
        novaEntrada->proximo = NULL;

        if (anterior) {
            anterior->proximo = novaEntrada;
        } else {
            hash->tabela[pos] = novaEntrada;
        }

        return 1;
    }
    return 0; // Tabela cheia
}

// Busca uma palavra na tabela hash
int buscaHash(HashTable *hash, char *palavra, EntradaHash **resultado) {
    if (!hash || !palavra) return 0;

    int idx = hashFunction1(palavra, hash->tamanho);
    int step = hash->hash2(palavra, hash->tamanho);

    for (int i = 0; i < hash->tamanho; i++) {
        int pos = (idx + i * step) % hash->tamanho;

        EntradaHash *atual = hash->tabela[pos];
        while (atual) {
            if (strcmp(atual->palavra, palavra) == 0) {
                *resultado = atual;
                return 1;
            }
            atual = atual->proximo;
        }
    }

    return 0; // Palavra não encontrada
}

