#ifndef INDICEINVERTIDO_H
#define INDICEINVERTIDO_H

#include "hash.h"

HashTable* aloca(int tamanho);
void libera(HashTable *indice);
int busca(char *palavra);
void consulta(HashTable *indice, char **palavras, int qtdPalavras);
void insereDocumento(char *palavra, char *documento);
void imprime(HashTable *indice);
void quickSort(Documento *documentos, int inicio, int fim);
int particiona(Documento *documentos, int inicio, int fim);
void lePalavra(HashTable *indice);

#endif // INDICEINVERTIDO_H