#include "indiceInvertido.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static HashTable *indice;

HashTable* aloca(int tamanho) {
    if (tamanho > MAX_TAMANHO_VOCABULARIO) return NULL;
    indice = criaHash(tamanho);
    return indice;
}

void libera(HashTable *hash) {
    if (!hash) return;
    for (int i = 0; i < hash->tamanho; i++) {
        EntradaHash *atual = hash->tabela[i];
        while (atual) {
            EntradaHash *temp = atual;
            atual = atual->proximo;
            free(temp);
        }
    }
    
    free(hash->tabela);
    free(hash);
}

void quickSort(Documento *documentos, int inicio, int fim) {
    if (inicio < fim) {
        int pivo = particiona(documentos, inicio, fim);
        quickSort(documentos, inicio, pivo - 1);
        quickSort(documentos, pivo + 1, fim);
    }
}

int particiona(Documento *documentos, int inicio, int fim) {
    char pivo[MAX_TAMANHO_DOCUMENTO + 1];
    strcpy(pivo, documentos[fim].nome);
    int i = inicio - 1;

    for (int j = inicio; j < fim; j++) {
        if (strcmp(documentos[j].nome, pivo) <= 0) {
            i++;
            Documento temp = documentos[i];
            documentos[i] = documentos[j];
            documentos[j] = temp;
        }
    }

    Documento temp = documentos[i + 1];
    documentos[i + 1] = documentos[fim];
    documentos[fim] = temp;

    return i + 1;
}


void insereDocumento(char *palavra, char *documento) {
    if (indice == NULL || palavra == NULL || documento == NULL) return;

    EntradaHash *resultado;
    if (buscaHash(indice, palavra, &resultado)) {
        // Verifica se o documento já está associado à palavra
        for (int i = 0; i < resultado->qtdDocumentos; i++) {
            if (strcmp(resultado->documentos[i].nome, documento) == 0) return; // Documento já associado
        }
        
        // Insere novo documento se houver espaço
        if (resultado->qtdDocumentos < MAX_DOCUMENTOS) {
            strncpy(resultado->documentos[resultado->qtdDocumentos].nome, documento, MAX_TAMANHO_DOCUMENTO);
            resultado->documentos[resultado->qtdDocumentos].nome[MAX_TAMANHO_DOCUMENTO] = '\0';
            resultado->qtdDocumentos++;
        }
    } else {
        // Palavra não encontrada, insere nova entrada
        insereHash(indice, palavra, documento);
    }
}

int busca(char *palavra) {
    if (indice == NULL || palavra == NULL) return 0;
    
    EntradaHash *resultado;
    return buscaHash(indice, palavra, &resultado);
}

void consulta(HashTable *indice, char **palavras, int qtdPalavras) {
    if (indice == NULL || palavras == NULL || qtdPalavras == 0 ) {
        printf("none\n");
        return;
    }
    // Array para armazenar documentos que contêm TODAS as palavras
    char documentosComuns[MAX_DOCUMENTOS][MAX_TAMANHO_DOCUMENTO + 1];
    int qtdDocumentosComuns = 0;
    int primeiroTermo = 1; // Flag para primeira palavra

    for (int i = 0; i < qtdPalavras; i++) {
        EntradaHash *resultado;
        if (!buscaHash(indice, palavras[i], &resultado)) {
            printf("none\n");
            return;
        }

        if (primeiroTermo) {
            // Primeira palavra: copia todos os documentos
            for (int j = 0; j < resultado->qtdDocumentos && j < MAX_DOCUMENTOS; j++) {
                strcpy(documentosComuns[qtdDocumentosComuns], resultado->documentos[j].nome);
                qtdDocumentosComuns++;
            }
            primeiroTermo = 0;
        } else {
            // Palavras seguintes: filtra documentos que estão em ambos
            int tempQtd = 0;
            char tempDocs[MAX_DOCUMENTOS][MAX_TAMANHO_DOCUMENTO + 1];

            for (int k = 0; k < qtdDocumentosComuns; k++) {
                for (int l = 0; l < resultado->qtdDocumentos; l++) {
                    if (strcmp(documentosComuns[k], resultado->documentos[l].nome) == 0) {
                        strcpy(tempDocs[tempQtd], documentosComuns[k]);
                        tempQtd++;
                        break;
                    }
                }
            }

            // Atualiza a lista de documentos comuns
            qtdDocumentosComuns = tempQtd;
            for (int m = 0; m < qtdDocumentosComuns; m++) {
                strcpy(documentosComuns[m], tempDocs[m]);
            }
        }

        if (qtdDocumentosComuns == 0) {
            printf("none\n");
            return;
        }
    }

    quickSort((Documento *)documentosComuns, 0, qtdDocumentosComuns - 1);

    // Imprime os resultados
    for (int i = 0; i < qtdDocumentosComuns; i++) {
        printf("%s\n", documentosComuns[i]);
    }
}

void lePalavra(HashTable *indice){
    char linha[MAX_TAMANHO_LINHA];
    if (fgets(linha, sizeof(linha), stdin) != NULL) {
        linha[strcspn(linha, "\n")] = '\0';
        char *palavras[MAX_PALAVRAS_BUSCADAS];
        int qtdPalavras = 0;

        char *palavra = strtok(linha, " ");
        while (palavra != NULL) {
            palavras[qtdPalavras++] = palavra;
            palavra = strtok(NULL, " ");
        }
        if (qtdPalavras > MAX_PALAVRAS_BUSCADAS) {
            printf("ERRO: quantidade de palavras buscadas(%d) exedem o limite máximo(%d)\n", qtdPalavras, MAX_PALAVRAS_BUSCADAS);
            return;
        } else 
            consulta(indice, palavras, qtdPalavras);
    }
}

void imprime(HashTable *indice) {
    if (indice == NULL) return;

    // Array para armazenar todas as entradas não vazias
    EntradaHash *entradas[MAX_TAMANHO_VOCABULARIO];
    int qtdEntradas = 0;

    //Coleta todas as entradas não vazias
    for (int i = 0; i < indice->tamanho; i++) {
        if (indice->tabela[i] != NULL && 
            strcmp(indice->tabela[i]->palavra, VAZIO) != 0 && 
            strcmp(indice->tabela[i]->palavra, REMOVIDO) != 0) {
            entradas[qtdEntradas++] = indice->tabela[i];
        }
    }

    // Imprime as entradas 
    for (int i = 0; i < qtdEntradas; i++) {
        printf("%s - ", entradas[i]->palavra);
        for (int j = 0; j < entradas[i]->qtdDocumentos; j++) {
            printf("%s", entradas[i]->documentos[j].nome);
            if (j < entradas[i]->qtdDocumentos - 1) {
                printf(" ");
            }
        }
        printf("\n");
    }
}